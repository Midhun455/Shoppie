package com.files.shoppie;

public class Offerzone {
    int imag;

    public Offerzone(int imag) {
        this.imag = imag;
    }

    public int getImag() {
        return imag;
    }

    public void setImag(int imag) {
        this.imag = imag;
    }
}
